<?php
//CE FICHIER CONTIENT TOUS LES CHEMINS RACINE

// Chemin du dossier racine du projet
define("ROOT", str_replace("public".DIRECTORY_SEPARATOR."index.php", "", $_SERVER["SCRIPT_FILENAME"]));

// Chemin du dossier controllers qui contient les controllers
define("PATH_CONTROLLERS", ROOT."controllers".DIRECTORY_SEPARATOR);

// Chemin du dossier models qui contient les modeles
define("PATH_MODELS", ROOT."models".DIRECTORY_SEPARATOR);

// Chemin du dossier data qui contient le fichier JSON 
define("PATH_DB", ROOT."data".DIRECTORY_SEPARATOR."tache.json");

// Chemin de mon serveur cest le point d'entrée des requêtes
define("WEB_ROOT","http://localhost/my_task/public");
