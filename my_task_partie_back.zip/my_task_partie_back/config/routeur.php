<?php
// LE ROUTER PERMET DE CHARGER LES CONTROLLERS
if(isset($_REQUEST["controller"])){
    switch($_REQUEST["controller"]){
        case "tache":
            require_once PATH_CONTROLLERS."tache.controller.php";
        break;
    }
}else
    require_once PATH_CONTROLLERS."tache.controller.php";
