<?php
    require_once PATH_MODELS."tache.model.php";

    //TRAITEMENTS DES REQUETES GET
    if($_SERVER["REQUEST_METHOD"] == "GET"){
        if(isset($_REQUEST["action"])){
            switch($_REQUEST["action"]){
                case "list_last_state":
                    echo find_last_state();      
                break;
                case "list_all_states":
                   echo get_all_states();    
                break;
            }
        }
    }

    //TRAITEMENTS DES REQUETES POST
    if($_SERVER["REQUEST_METHOD"] == "POST"){
        if(isset($_REQUEST["action"])){
            switch($_REQUEST["action"]){
                case "save_state":
                    $tab = json_decode(file_get_contents('php://input'), true);
                    save_data("states", $tab);
                break;
            }
        }
    }
    
 