<?php
    function add_state(string $states, array $newRegistration):bool{
        save_data($states, $newRegistration);
    }

    function get_all_states(){
        $all_states = find_data("states");
        return json_encode($all_states);
    }

    function find_last_state(){
        $result = find_data("states");
        return json_encode($result[count($result) - 1]);
    }
