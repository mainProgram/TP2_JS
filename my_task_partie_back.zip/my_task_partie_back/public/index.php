<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: OPTIONS,GET,POST,PUT,DELETE");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$rootDirectory =  dirname(dirname(__FILE__)); 

//Inclusion des constantes
require_once $rootDirectory.DIRECTORY_SEPARATOR."config".DIRECTORY_SEPARATOR."constantes.php";

//Inclusion de l'ORM
require_once $rootDirectory.DIRECTORY_SEPARATOR."config".DIRECTORY_SEPARATOR."orm.php";

//Chargement du routeur
require_once $rootDirectory.DIRECTORY_SEPARATOR."config".DIRECTORY_SEPARATOR."routeur.php";